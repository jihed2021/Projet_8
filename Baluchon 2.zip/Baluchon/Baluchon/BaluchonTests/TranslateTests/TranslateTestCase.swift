//
//  TranslateTestCase.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 29/09/2021.
//

import XCTest
@testable import Baluchon

class TranslateTestCase: XCTestCase {

    func testGetTranslateShouldPostFailedCallbackIfError() {
        
        let translateService = Translate(translateSession: URLSessionFake(data: nil, response: nil, error: FakeResponseTranslateData.error))
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate(text: "Hello world") { success, translateInfo in
            XCTAssertFalse(success)
            XCTAssertNil(translateInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslateShouldPostFailedCallbackIfNoData() {
       
        let translateService = Translate(translateSession: URLSessionFake(data: nil, response: nil, error: nil))
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate(text: "Hello world") { success, translateInfo in
            XCTAssertFalse(success)
            XCTAssertNil(translateInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslateShouldPostFailedCallbackIfIncorrectResponse() {
        
       
        let translateService = Translate(translateSession: URLSessionFake(data: FakeResponseTranslateData.quoteCorrectData, response: FakeResponseTranslateData.responseKO, error: nil))
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate(text: "Hello world") { success, translateInfo in
            XCTAssertFalse(success)
            XCTAssertNil(translateInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslateShouldPostFailedCallbackIfIncorrectData() {

        let translateService = Translate(translateSession: URLSessionFake(data: FakeResponseTranslateData.quoteIncorrectData, response: FakeResponseTranslateData.responseOK, error: nil))
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        translateService.getTranslate(text: "Hello world") { success, translateInfo in
            XCTAssertFalse(success)
            XCTAssertNil(translateInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetTranslateShouldPostFailedCallbackIfNoErrorAndCorrectData() {
        
        let translateService = Translate(translateSession: URLSessionFake(data: FakeResponseTranslateData.quoteCorrectData, response: FakeResponseTranslateData.responseOK, error: nil))
        let expectation = XCTestExpectation(description: "Wait for queue change.")
       
        translateService.getTranslate(text: "Hello world") { success, translateInfo in
            let translatedText  = "mon nom est jihed"
            XCTAssertTrue(success)
            XCTAssertNotNil(translateInfo)
            XCTAssertEqual(translatedText, translateInfo?.translatedText)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 10)
    }
    func testInitForTranslate() {
        let translateservice = Translate()
        XCTAssertNotNil(translateservice)
    }
}
