//
//  FakeResponseTranslateData.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 30/09/2021.
//

import Foundation
class FakeResponseTranslateData {
   static let responseOK = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 200, httpVersion: nil, headerFields: nil)!
   static let responseKO = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 400, httpVersion: nil, headerFields: nil)!
    
    class TranslateError: Error {}
    
    static let error = TranslateError()

   static var quoteCorrectData: Data {
        let bundle = Bundle(for: FakeResponseTranslateData.self)
       let url = bundle.url(forResource: "TranslateInfo", withExtension: "json")
       
       let data = try! Data(contentsOf: (url!))
        return data
    }
    
    static let quoteIncorrectData = "erreur".data(using: .utf8)
}
