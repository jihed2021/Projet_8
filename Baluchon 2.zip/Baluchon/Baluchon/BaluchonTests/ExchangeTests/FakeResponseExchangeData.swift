//
//  FakeResponseExchangeData.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 30/09/2021.
//

import Foundation

class FakeResponseExchangeData {
   static let responseOK = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 200, httpVersion: nil, headerFields: nil)!
   static let responseKO = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 400, httpVersion: nil, headerFields: nil)!
    
    class ExchangeError: Error {}
    
    static let error = ExchangeError()

   static var quoteCorrectData: Data {
        let bundle = Bundle(for: FakeResponseExchangeData.self)
       let url = bundle.url(forResource: "ExchangeInfo", withExtension: "json")
       
       let data = try! Data(contentsOf: (url!))
        return data
    }
    
    static let quoteIncorrectData = "erreur".data(using: .utf8)
}
