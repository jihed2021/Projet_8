//
//  ExchangeTestCase.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 29/09/2021.
//

import XCTest
@testable import Baluchon

class ExchangeTestCase: XCTestCase {
    
        func testGetExchangeShouldPostFailedCallbackIfError() {
            
            let exchangeService = Exchange(session: URLSessionFake(data: nil, response: nil, error: FakeResponseExchangeData.error))
            let expectation = XCTestExpectation(description: "Wait for queue change.")
            exchangeService.getRates(amountToExchange: 100) { success, rateInfo in
                XCTAssertFalse(success)
                XCTAssertNil(rateInfo)
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 0.01)
        }
    
        func testGetExchangeShouldPostFailedCallbackIfNoData() {
            let exchangeService = Exchange(session: URLSessionFake(data: nil, response: nil, error: nil))
            let expectation = XCTestExpectation(description: "Wait for queue change.")
            exchangeService.getRates(amountToExchange: 100) { success, rateInfo in
                //Then
                XCTAssertFalse(success)
                XCTAssertNil(rateInfo)
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 0.01)
        }
    
        func testGetExchangeShouldPostFailedCallbackIfIncorrectResponse() {
            
            let exchangeService = Exchange(session: URLSessionFake(data: FakeResponseExchangeData.quoteCorrectData, response: FakeResponseExchangeData.responseKO, error: nil))
            let expectation = XCTestExpectation(description: "Wait for queue change.")
            exchangeService.getRates(amountToExchange: 100) { success, rateInfo in
                XCTAssertFalse(success)
                XCTAssertNil(rateInfo)
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 0.01)
        }
    
        func testGetExchangeShouldPostFailedCallbackIfIncorrectData() {
            
            let exchangeService = Exchange(session: URLSessionFake(data: FakeResponseExchangeData.quoteIncorrectData, response: FakeResponseExchangeData.responseOK, error: nil))
            let expectation = XCTestExpectation(description: "Wait for queue change.")
            exchangeService.getRates(amountToExchange: 100) { success, rateInfo in
                XCTAssertFalse(success)
                XCTAssertNil(rateInfo)
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 0.01)
        }
    
        func testGetExchangeShouldPostFailedCallbackIfNoErrorAndCorrectData() {
            
            let exchangeService = Exchange(session: URLSessionFake(data: FakeResponseExchangeData.quoteCorrectData, response: FakeResponseExchangeData.responseOK, error: nil))
            let expectation = XCTestExpectation(description: "Wait for queue change.")
            exchangeService.getRates(amountToExchange: 100) { success, rateInfo in
                let USD = 1.167726
                XCTAssertTrue(success)
                XCTAssertNotNil(rateInfo)
                XCTAssertEqual(Float(USD), rateInfo!.rate)
                expectation.fulfill()
            }
            wait(for: [expectation], timeout: 0.01)
        }
    func testInit() {
        let exchangeService  = Exchange()
        XCTAssertNotNil(exchangeService)
    }
}
