//
//  FakeResponseMeteoData.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 29/09/2021.
//

import Foundation

class FakeResponseMeteoData {
   static let responseOK = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 200, httpVersion: nil, headerFields: nil)!
   static let responseKO = HTTPURLResponse(url: URL(string: "https://openclassrooms.com")!, statusCode: 400, httpVersion: nil, headerFields: nil)!
    
    class WeatherError: Error {}
    
    static let error = WeatherError()
    static var quoteCorrectData: Data {
        let bundle = Bundle(for: FakeResponseMeteoData.self)
       let url = bundle.url(forResource: "WeatherInfo", withExtension: "json")
       
       let data = try! Data(contentsOf: (url!))
        return data
    }
    
    static let quoteIncorrectData = "erreur".data(using: .utf8)
}
