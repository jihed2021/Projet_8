//
//  MeteoTestCase.swift
//  BaluchonTests
//
//  Created by Jihed Agrebaoui on 29/09/2021.
//

import XCTest
@testable import Baluchon

class WeatherTestCase: XCTestCase {

    func testGetWeatherShouldPostFailedCallbackIfError() {
        //Given
        let weatherService = WeatherService(session: URLSessionFake(data: nil, response: nil, error: FakeResponseMeteoData.error))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
                                        
        weatherService.getweather(city: "London") { success, meteoInfo in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(meteoInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfNoData() {
        //Given
        let weatherService = WeatherService(session: URLSessionFake(data: nil, response: nil, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
                                        
        weatherService.getweather(city: "London") { success, meteoInfo in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(meteoInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfIncorrectResponse() {
        //Given
        let weatherService = WeatherService(session: URLSessionFake(data: FakeResponseMeteoData.quoteCorrectData, response: FakeResponseMeteoData.responseKO, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
                                        
        weatherService.getweather(city: "London") { success, meteoInfo in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(meteoInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfIncorrectData() {
        //Given
        let weatherService = WeatherService(session: URLSessionFake(data: FakeResponseMeteoData.quoteIncorrectData, response: FakeResponseMeteoData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
                                        
        weatherService.getweather(city: "London") { success, meteoInfo in
            //Then
            XCTAssertFalse(success)
            XCTAssertNil(meteoInfo)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    func testGetWeatherShouldPostFailedCallbackIfNoErrorAndCorrectData() {
        //Given
        let weatherService = WeatherService(session: URLSessionFake(data: FakeResponseMeteoData.quoteCorrectData, response: FakeResponseMeteoData.responseOK, error: nil))
        //When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
                                        
        weatherService.getweather(city: "California") { success, weatherInfo in
            //Then
            let temp = 12.28
            let temp_min = 9.06
            let temp_max = 16.48
            let humidity = 94
            let windSpeed = 0
            XCTAssertTrue(success)
            XCTAssertNotNil(weatherInfo)
            XCTAssertEqual(humidity, Int(weatherInfo!.humidity))
            XCTAssertEqual(windSpeed, Int(weatherInfo!.speed))
            XCTAssertEqual(Int(temp), Int(weatherInfo!.temp))
            XCTAssertEqual(Int(temp_max), Int(weatherInfo!.temp_max))
            XCTAssertEqual(Int(temp_min), Int(weatherInfo!.temp_min))
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
 
    }
    
    func testInitForWeather() {
        let weatherService = WeatherService()
        XCTAssertNotNil(weatherService)
    }
}
