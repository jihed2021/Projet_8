//
//  ViewController.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 26/09/2021.
//

import UIKit

enum WeatherError: Error , LocalizedError {
    case textFieldEmpty, alertExpression
    public var errorDescription: String? {
        switch self {
        case .textFieldEmpty:
            return "Enter text to translate❗️"
        case .alertExpression:
            return "Error"
        }
    }
}

class WeatherViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var temp_max_Label: UILabel!
    @IBOutlet weak var temp_min_Label: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var WindSpeedLabel: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var weather: UILabel!
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func getWeatherInfo() {
        
        guard let city = textField.text, city.isEmpty == false else {
            return presentAlertForTextField(message: WeatherError.textFieldEmpty.localizedDescription)
        }
        WeatherService.shared.getweather(city:city) {(success, weatherInfo) in
            if success, let weatherInfo = weatherInfo {
                self.update(weatherResults: weatherInfo)
                self.cityName.text = city
                self.date.text = self.dateInfo()
            } else {
                self.presentAlert(message: WeatherError.alertExpression.localizedDescription)
            }
        }
    }
    
    private func update(weatherResults: WeatherInfo) {
        tempLabel.text = String(weatherResults.temp) + "°C"
        temp_max_Label.text = "Temperature Max: " + String(weatherResults.temp_max) + "°C"
        temp_min_Label.text = "Temperature min: " + String(weatherResults.temp_min) + "°C"
        WindSpeedLabel.text = "Wind speed: " + String(weatherResults.speed) + " Km/h"
        humidityLabel.text = "Humidity: " + String(weatherResults.humidity)
        weather.text = weatherResults.weather
    }
    
    private func presentAlert(message: String) {
        let alertVC = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    
    private func presentAlertForTextField(message: String) {
        let alertVC = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    
    private func dateInfo() -> String {
        let dateInfo: String
        let now = Date()
        let english       = DateFormatter()
        english.dateStyle = .medium
        english.timeStyle = .medium
        english.locale    = Locale(identifier: "EN-en")
        dateInfo = english.string(from: now)
        return dateInfo
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func dismissKeyBoard(_ sender: UITapGestureRecognizer) {
        textField.resignFirstResponder()
    }
    
}

