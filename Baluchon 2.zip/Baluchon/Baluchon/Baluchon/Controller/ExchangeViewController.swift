//
//  ExchangeViewController.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 27/09/2021.
//

import UIKit

enum ExchangeError: Error , LocalizedError {
    case textFieldEmpty, alertExpression
    public var errorDescription: String? {
        switch self {
        case .textFieldEmpty:
            return "Enter value to exchange❗️"
        case .alertExpression:
            return "Error"
        }
    }
}

class ExchangeViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var exhangeLabel: UILabel!
    @IBOutlet weak var baseLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var totalExchangeValue: UILabel!

    @IBAction func GetExchangeRate() {
        guard let amount = textField.text, let amountToExchange = Float(amount) else {
            self.presentAlert(message: ExchangeError.textFieldEmpty.localizedDescription)
            return
        }
        
        Exchange.shared.getRates(amountToExchange: amountToExchange) { success, rateInfo in
            if success, let rateInfo = rateInfo {
                self.updateRates(rateInfo: rateInfo)
            } else {
                self.presentAlert(message: ExchangeError.alertExpression.localizedDescription)
            }
        }
    }
    
    private func updateRates(rateInfo: RatesInfo) {
        exhangeLabel.text = "1,000 EUR = " + String(rateInfo.rate) + " USD"
        baseLabel.text = "base: " + rateInfo.base
        dateLabel.text = "date: " + rateInfo.date
        totalExchangeValue.text = String(rateInfo.totalRates) + " USD"
    }
    
    private func presentAlert(message: String) {
        let alertVC = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
    
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        textField.resignFirstResponder()
    }
}
