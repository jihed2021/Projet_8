//
//  TranslateViewController.swift
//  Baluchon
//
//  Created by Jihed Agrebaoui on 28/09/2021.
//

import UIKit

enum TranslateError: Error , LocalizedError {
    case textFieldEmpty, alertExpression
    public var errorDescription: String? {
        switch self {
        case .textFieldEmpty:
            return "Enter text to translate❗️"
        case .alertExpression:
            return "Error"
        }
    }
}


class TranslateViewController: UIViewController {

    @IBOutlet weak var textFieldToTranslate: UITextView!
    @IBOutlet weak var textFieldTranslated: UITextView!
    @IBOutlet weak var baseLanguage: UILabel!
    @IBOutlet weak var targetLanguage: UILabel!
    
    @IBOutlet weak var buttonForTranslate: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldToTranslate.layer.cornerRadius = 15
        textFieldToTranslate.layer.borderColor = UIColor.gray.withAlphaComponent(1).cgColor
        textFieldToTranslate.layer.borderWidth = 1.5
        textFieldToTranslate.clipsToBounds = true
        textFieldTranslated.layer.cornerRadius = 15
        textFieldTranslated.layer.borderColor = UIColor.gray.withAlphaComponent(1).cgColor
        textFieldTranslated.layer.borderWidth = 1.5
        textFieldTranslated.clipsToBounds = true
        updateLabelStyle()
    }
    @IBAction func translate() {
        
        guard let newText = textFieldToTranslate.text, newText.isEmpty == false else {
            presentAlert(message: TranslateError.textFieldEmpty.localizedDescription)
            return
        }
        Translate.shared.getTranslate(text: newText) { success, translateInfo in
            if success , let translateInfo = translateInfo {
                self.updateText(translateInfo: translateInfo)
            } else {
                self.presentAlert(message: TranslateError.alertExpression.localizedDescription)
            }
        }
       
    }
    
    private func updateText(translateInfo:TranslateInfo) {
        textFieldToTranslate.text = translateInfo.textToTranslate
        textFieldTranslated.text = translateInfo.translatedText
        baseLanguage.text = translateInfo.detectedSourceLanguage
        targetLanguage.text = translateInfo.targetLanguage
    }
    
    private func presentAlert(message: String) {
        let alertVC = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    private func updateLabelStyle() {
        baseLanguage.layer.cornerRadius = 5
        baseLanguage.layer.borderColor = UIColor.gray.withAlphaComponent(0.5).cgColor
        baseLanguage.layer.borderWidth = 0.5
        baseLanguage.clipsToBounds = true
        targetLanguage.layer.cornerRadius = 5
        targetLanguage.layer.borderColor = UIColor.gray.withAlphaComponent(0.5).cgColor
        targetLanguage.layer.borderWidth = 0.5
        targetLanguage.clipsToBounds = true
        buttonForTranslate.layer.cornerRadius = 5
        buttonForTranslate.layer.borderColor = UIColor.gray.withAlphaComponent(0.5).cgColor
        buttonForTranslate.layer.borderWidth = 0.5
        buttonForTranslate.clipsToBounds = true
    }
}
