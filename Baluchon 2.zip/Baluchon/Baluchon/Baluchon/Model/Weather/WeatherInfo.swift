//
//  File.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 26/09/2021.
//

import Foundation
struct WeatherInfo {
    var temp: Int
    var temp_min: Int
    var temp_max: Int
    var humidity: Int
    var speed: Int
    var weather: String
}
