//
//  WeatherService.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 26/09/2021.
//

import Foundation

struct APIResponse: Codable {
    let main: MteoInfo
    let wind: WindInfo
    let weather: [Weather]
}

struct MteoInfo: Codable {
    let temp: Double
    let temp_min: Double
    let temp_max: Double
    let humidity: Int
}
struct WindInfo: Codable {
    let speed: Float
}
struct Weather: Codable {
    let description: String
}

class WeatherService {
static let shared = WeatherService()

    private var session: URLSession
    private var task: URLSessionDataTask?
    
    init(session: URLSession? = nil) {
        self.session = session ?? URLSession(configuration: .default)
    }
    
    func getweather(city: String, callback:@escaping (Bool, WeatherInfo?) -> Void) {
        guard let url = URL(string: "https:/api.openweathermap.org/data/2.5/weather?q=\(city)&appid=86423c05e6cc72357bc634caa893ce8d&units=metric") else {
            return
        }
        task?.cancel()
        task = session.dataTask(with: url, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async {
                guard let data = data , error == nil else {
                    callback(false, nil)
                    return
                }
                guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                    callback(false, nil)
                    return
                }
                var result: APIResponse!
                do {
                    result = try JSONDecoder().decode(APIResponse.self, from: data)
                } catch {
                    callback(false, nil)
                    return
                }
            
                let temp = Int(result.main.temp)
                let temp_min = Int(result.main.temp_min)
                let temp_max = Int(result.main.temp_max)
                let humidity = result.main.humidity
                let windSpeed = Int(result.wind.speed * 3.6)
                let weatherInfo = result.weather.first?.description
                let meteoInfo = WeatherInfo(temp: temp, temp_min: temp_min, temp_max: temp_max, humidity: humidity, speed: windSpeed, weather: weatherInfo ?? "")
                callback(true, meteoInfo)
            }
            }
        )
        task!.resume()
    }
        
}

