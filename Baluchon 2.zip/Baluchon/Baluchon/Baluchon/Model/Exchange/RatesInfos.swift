//
//  RatesInfos.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 27/09/2021.
//

import Foundation

struct RatesInfo {
    
    var base: String
    var date: String
    var rate: Float
    var totalRates: Float
}

