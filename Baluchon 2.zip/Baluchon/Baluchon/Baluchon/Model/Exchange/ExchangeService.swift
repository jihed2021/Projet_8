//
//  ExchangeService.swift
//  meteo
//
//  Created by Jihed Agrebaoui on 27/09/2021.
//

import Foundation

struct APIEXchangeResponse: Codable {
    let base: String
    let date : String
    let rates:Rates
}

struct Rates: Codable {
    let USD: Float
}

class Exchange {
    
    static let shared = Exchange()
    
    private var session: URLSession
    private var taskExchange: URLSessionDataTask?
    
    init(session: URLSession? = nil ) {
        self.session = session ?? URLSession(configuration: .default)
    }
    
    func getRates(amountToExchange:Float, callback:@escaping ((Bool, RatesInfo?) -> Void)) {
        guard let url = URL(string: "http://data.fixer.io/api/latest?access_key=ff95856add94616d6a92511fd614c24f&symbols=USD,AUD,CAD,PLN,MXN&format=1") else{
            return
        }
        taskExchange?.cancel()
        taskExchange = session.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                guard let data = data , error == nil else{
                    callback(false, nil)
                    return
                }
                guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                    callback(false, nil)
                    return
                }
                
                var ratesResults: APIEXchangeResponse!
                
                do {
                    ratesResults = try JSONDecoder().decode(APIEXchangeResponse.self, from: data)
                }
                catch {
                    callback(false, nil)
                    return
                }
           
                let usd = ratesResults.rates.USD
                let date = ratesResults.date
                let base = ratesResults.base
                let total = amountToExchange * usd
                let rateInfo = RatesInfo(base: base, date: date, rate: usd, totalRates: total)
                callback(true, rateInfo)
            }
        }
        taskExchange!.resume()
    }
}
