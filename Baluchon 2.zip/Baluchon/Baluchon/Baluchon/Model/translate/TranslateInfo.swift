//
//  TranslateInfo.swift
//  Baluchon
//
//  Created by Jihed Agrebaoui on 28/09/2021.
//

import Foundation

struct TranslateInfo {
    
    var textToTranslate: String
    var translatedText: String
    var detectedSourceLanguage: String
    var targetLanguage: String
    
    init (apiModel: APITranslateResponse, textToTranslate: String, targetLanguage: String ){
        self.textToTranslate = textToTranslate
        self.translatedText = apiModel.data.translations.first?.translatedText ?? ""
        self.detectedSourceLanguage = apiModel.data.translations.first?.detectedSourceLanguage ?? ""
        self.targetLanguage = targetLanguage
    }
}

