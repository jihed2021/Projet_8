//
//  translateService.swift
//  Baluchon
//
//  Created by Jihed Agrebaoui on 28/09/2021.
//

import Foundation


struct APITranslateResponse: Codable {
    let data: APIResponseTranslation
}

struct APIResponseTranslation: Codable {
    let translations: [TranslateText]
}

struct TranslateText: Codable{
    let translatedText: String
    let detectedSourceLanguage: String
}

class Translate {
    
    static let shared = Translate()
    
    private var translateSession: URLSession
    private var translateTask: URLSessionDataTask?
    
    init(translateSession: URLSession? = nil) {
        self.translateSession = translateSession ?? URLSession(configuration: .default)
    }
    
    func getTranslate(text: String, callback:@escaping (Bool, TranslateInfo?) -> Void) {
        let parameters = Translate.Params(q: text)
        let url = parameters.getUrl()
        
        translateTask?.cancel()
        translateTask = translateSession.dataTask(with: url, completionHandler: { data, response, error in
            DispatchQueue.main.async {
                guard let data = data , error == nil else {
                    callback(false, nil)
                    return
                }
                guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                    callback(false, nil)
                    return
                }
                var result: APITranslateResponse!
                do {
                    result = try JSONDecoder().decode(APITranslateResponse.self, from: data)
                } catch {
                    callback(false, nil)
                    return
                }
                
                callback(true, TranslateInfo(apiModel: result, textToTranslate: parameters.q, targetLanguage: Translate.Params.target))
            }
        }
        )
        translateTask?.resume()
        
    }
    
    
    struct Params {
        let key: String = "AIzaSyAlcBf-VuQLDgUE6f7VFd251cLY2URNhtQ"
        let q: String
        static let target: String = "fr"
        let format: String = "text"
        let model: String = "base"
        let baseUrl = "https://translation.googleapis.com/language/translate/v2"
        
        func getUrl() -> URL {
            var queryComponent = URLComponents(string: baseUrl)!
            let keyComponent = URLQueryItem(name: "key", value: key)
            let qComponent = URLQueryItem(name: "q", value: q)
            let targetComponent = URLQueryItem(name: "target", value: Translate.Params.target)
            let formatComponent = URLQueryItem(name: "format", value: format)
            let modelComponent = URLQueryItem(name: "model", value: model)
            queryComponent.queryItems = [keyComponent, qComponent, targetComponent, formatComponent, modelComponent]
            return queryComponent.url!
        }
        
        
    }

}
